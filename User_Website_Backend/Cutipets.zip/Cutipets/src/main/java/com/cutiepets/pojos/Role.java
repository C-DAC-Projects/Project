package com.cutiepets.pojos;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Role {

    private Integer id;
    private String name;
}
